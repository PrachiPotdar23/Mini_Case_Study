package com.example.demo.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Product;
import com.example.demo.service.ProductService;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    // User - Get all products
    @GetMapping("/user/getall")
    //@PreAuthorize("hasRole('ROLE_USER')")  // Ensure only 'USER' can access this
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    // User - Get product by ID
    @GetMapping("/user/getproduct/{id}")
    //@PreAuthorize("hasRole('ROLE_USER')")  // Ensure only 'USER' can access this
    public Optional<Product> getProductById(@PathVariable Long id) {
        return productService.getProductById(id);
    }

    // Admin - Add or Update a product
    @PostMapping("/admin/add")
    //@PreAuthorize("hasRole('ROLE_ADMIN')")  // Ensure only 'ADMIN' can access this
    public Product addOrUpdateProduct(@RequestBody Product product) {
        return productService.saveProduct(product);
    }

    // Admin - Update a product
    @PutMapping("/admin/update/{id}")
    //@PreAuthorize("hasRole('ROLE_ADMIN')")  // Ensure only 'ADMIN' can access this
    public Product updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct) {
        return productService.updateProduct(id, updatedProduct);
    }

    // Admin - Delete a product
    @DeleteMapping("/admin/delete/{id}")
    //@PreAuthorize("hasRole('ROLE_ADMIN')")  // Ensure only 'ADMIN' can access this
    public void deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
    }
}
