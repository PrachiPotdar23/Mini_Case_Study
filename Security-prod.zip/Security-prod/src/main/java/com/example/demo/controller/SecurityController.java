//package com.example.demo.controller;
//
//import com.example.demo.client.ProductFeignClient;
//import com.example.demo.entity.Product;
//import com.example.demo.config.JwtUtil;
//import io.jsonwebtoken.Claims;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.Optional;
//
//@RestController
//@RequestMapping("/api/auth")
//public class SecurityController {
//
//    @Autowired
//    private ProductFeignClient productFeignClient;
//
//    @Autowired
//    private JwtUtil jwtUtil;
//
//    // Get all products - Only accessible by USER
//    @GetMapping("/products/user/getall")
//    public List<Product> getAllProducts(@RequestHeader("Authorization") String token) {
//        String role = getRoleFromToken(token);  // Extract the role from the token
//
//        if (!role.equalsIgnoreCase("USER")) {
//            throw new SecurityException("You must have 'USER' role to access this resource");
//        }
//
//        return productFeignClient.getAllProducts();  // Call Product Service to get products
//    }
//
//    // Get product by ID - Only accessible by USER
//    @GetMapping("/products/user/getproduct/{id}")
//    public Optional<Product> getProductById(@PathVariable Long id, @RequestHeader("Authorization") String token) {
//        String role = getRoleFromToken(token);  // Extract the role from the token
//
//        if (!role.equalsIgnoreCase("USER")) {
//            throw new SecurityException("You must have 'USER' role to access this resource");
//        }
//
//        return productFeignClient.getProductById(id);  // Call Product Service to get product by ID
//    }
//
//    // Add or Update a product - Only accessible by ADMIN
//    @PostMapping("/products/admin/add")
//    public Product addOrUpdateProduct(@RequestBody Product product, @RequestHeader("Authorization") String token) {
//        String role = getRoleFromToken(token);  // Extract the role from the token
//
//        if (!role.equalsIgnoreCase("ADMIN")) {
//            throw new SecurityException("You must have 'ADMIN' role to add or update products");
//        }
//
//        return productFeignClient.addOrUpdateProduct(product);  // Call Product Service to add/update product
//    }
//
//    // Update a product - Only accessible by ADMIN
//    @PutMapping("/products/admin/update/{id}")
//    public Product updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct, @RequestHeader("Authorization") String token) {
//        String role = getRoleFromToken(token);  // Extract the role from the token
//
//        if (!role.equalsIgnoreCase("ADMIN")) {
//            throw new SecurityException("You must have 'ADMIN' role to update products");
//        }
//
//        return productFeignClient.updateProduct(id, updatedProduct);  // Call Product Service to update the product
//    }
//
//    // Delete a product - Only accessible by ADMIN
//    @DeleteMapping("/products/admin/delete/{id}")
//    public void deleteProduct(@PathVariable Long id, @RequestHeader("Authorization") String token) {
//        String role = getRoleFromToken(token);  // Extract the role from the token
//
//        if (!role.equalsIgnoreCase("ADMIN")) {
//            throw new SecurityException("You must have 'ADMIN' role to delete products");
//        }
//
//        productFeignClient.deleteProduct(id);  // Call Product Service to delete product
//    }
//
//    // Helper method to extract role from JWT token
//    private String getRoleFromToken(String token) {
//        if (token == null || token.isEmpty()) {
//            throw new SecurityException("Token is missing or empty");
//        }
//
//        String jwtToken = token.startsWith("Bearer ") ? token.substring(7) : token;  // Remove "Bearer " prefix
//
//        try {
//            Claims claims = jwtUtil.extractClaims(jwtToken);  // Modify this method to return Claims
//            return claims.get("role", String.class);  // Extract role from claims
//        } catch (Exception e) {
//            throw new SecurityException("Failed to extract role from token: " + e.getMessage());
//        }
//    }
//}
