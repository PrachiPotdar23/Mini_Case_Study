package com.example.demo.client;

import com.example.demo.entity.Product;  // Import the Product entity (not in Security Service, just for FeignClient)
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@FeignClient(name = "PRODUCT")  // URL of your Product Service
public interface ProductFeignClient {

    @GetMapping("/products/user/getall")  // Get all products
    List<Product> getAllProducts();

    @GetMapping("/products/user/getproduct/{id}")  // Get a product by ID
    Optional<Product> getProductById(@PathVariable Long id);

    @PostMapping("/products/admin/add")  // Add or update a product
    Product addOrUpdateProduct(@RequestBody Product product);

    @PutMapping("/products/admin/update/{id}")  // Update a product by ID
    Product updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct);  // Update a product

    @DeleteMapping("/products/admin/delete/{id}")  // Delete a product by ID
    void deleteProduct(@PathVariable Long id);
}
